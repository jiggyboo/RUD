# from flask import Flask, request, jsonify, current_app, Response, g, stream_with_context
# from flask.json import JSONEncoder
# from sqlalchemy import create_engine, text
from datetime import date
from functools import wraps
from flask_cors import CORS
import bcrypt
import jwt
# import requests
# import praw
# from praw_info import prawInfo

# Set cannot be jsonified. So have to use a custom json encoder.
class CustomJSONEncoder(JSONEncoder):
	def default(self, obj):
		if isinstance(obj, set):
			return list(obj)

		return JSONEncoder.default(self, obj)

###############################################################
#                            MYSQL                            #
###############################################################

# def dateToDT(date):
# 	dates = [date+" 00:00:00", date+" 23:59:59"]
# 	return dates

# def getT_url(url):
# 	sdate = dateToDT(url['sdate'])
# 	rurl = current_app.database.execute(text("""
# 		SELECT
# 			id,
# 			urls
# 		FROM urls
# 		WHERE sub = :sub_name AND type = :url_type AND created_at >= :url_dateA AND created_at <= :url_dateB AND time = :url_time
# 		"""), {
# 			'sub_name' : url['sub'],
# 			'url_type' : url['stype'],
# 			'url_dateA' : sdate[0],
# 			'url_dateB' : sdate[1],
# 			'url_time' : url['stim']
# 		}).fetchone()

# 	return {
# 		'id' : rurl['id'],
# 		'sub' : url['sub'],
# 		'urls' : rurl['urls']
# 	} if rurl else None

# def get_url(url):
# 	sdate = dateToDT(url['sdate'])
# 	rurl = current_app.database.execute(text("""
# 		SELECT
# 			id,
# 			urls
# 		FROM urls
# 		WHERE sub = :sub_name AND type = :url_type AND created_at >= :url_dateA AND created_at <= :url_dateB
# 		"""), {
# 			'sub_name' : url['sub'],
# 			'url_type' : url['stype'],
# 			'url_dateA' : sdate[0],
# 			'url_dateB' : sdate[1]
# 		}).fetchone()

# 	return {
# 		'id' : rurl['id'],
# 		'sub' : url['sub'],
# 		'urls' : rurl['urls']
# 	} if rurl else None

# def get_url_id(id):
# 	content = current_app.database.execute(text("""
# 		SELECT
# 			id,
# 			sub,
# 			urls,
# 			type,
# 			time
# 		FROM
# 			urls
# 		WHERE
# 			id = :pid
# 	"""),{'pid':id}).fetchone()

# 	return content
	

# def get_sub(sub):
# 	subn = current_app.database.execute(text("""
# 	SELECT 
# 		sub
# 	FROM subs
# 	WHERE sub = :sub_name
# 	"""), {
# 		'sub_name' : sub
# 	}).fetchone()
# 	return subn

# def insert_url(url):
# 	return current_app.database.execute(text("""
# 		INSERT INTO urls (
# 			urls,
# 			type,
# 			time,
# 			nump,
# 			sub,
# 			nsfw
# 		) VALUES (
# 			:urls,
# 			:type,
# 			:time,
# 			:nump,
# 			:sub,
# 			:nsfw
# 		)
# 	"""), url).lastrowid

# def insert_sub(sub):
# 	return current_app.database.execute(text("""
# 		INSERT INTO subs (
# 			sub,
# 			nsfw
# 		) VALUES (
# 			:sub,
# 			:nsfw
# 		)
# 	"""), sub).lastrowid

# # Increasing hits/viewcount to play with statistics.
# def increment_hits_sub(subname):
# 	current_app.database.execute(text("""
# 	UPDATE subs
# 		SET hits = hits + 1
# 		WHERE sub = :subname
# 	"""), {
# 		'subname' : subname
# 	})

# def increment_hits_url(id):
# 	current_app.database.execute(text("""
# 	UPDATE urls
# 	SET hits = hits + 1
# 	WHERE id = :sub_id
# 	"""), {
# 		'sub_id' : id
# 	})

# def increment_vc_sub(subname):
#         current_app.database.execute(text("""
#         UPDATE subs
#                 SET viewcount = viewcount + 1
#                 WHERE sub = :subname
#         """), {
#                 'subname' : subname
#         })

# def increment_vc_url(id):
#         current_app.database.execute(text("""
#         UPDATE urls
#                 SET viewcount = viewcount + 1
#                 WHERE id = :sub_id
#         """), {
#                 'sub_id' : id
#         })

# ## Searches Reddit using PRAW, returns urls of downloadable contents of each items in the sub.
# def search_sub(sub,tim,type,num=30):
# 	urls = []

# 	reddit = praw.Reddit(client_id=prawInfo['client_id'], \
#                      client_secret=prawInfo['client_secret'], \
#                      user_agent=prawInfo['user_agent'], \
#                      username=prawInfo['username'], \
#                      password=prawInfo['password'])
# 	subred = reddit.subreddit(sub)
# 	if type == 'top':
# 		posts = subred.top(time_filter=tim, limit=num)
# 	elif type == 'new':
# 		posts = subred.new(limit = num)
# 	elif type == 'hot':
# 		posts = subred.hot(limit = num)
# 	for post in posts:
# 		try:
# 			url = post.url
# 			extens = url.split(".")[-1]
# 			if extens == 'jpg' or extens == 'png':
# 				urls.append(url)
# 			elif extens == 'gifv':
# 				urls.append(url)
# 			elif url.split('/')[2] == 'redgifs.com':
# 				try:
# 					r = requests.get(url)
# 					spl = r.text.split('/')
# 					num = 88
# 					for i in range(5):
# 						if spl[num+i].rfind('.mp4') != -1:
# 							mark = spl[num+i].split('"')[0]
# 					url = 'https://thumbs2.redgifs.com/'+mark
# 					urls.append(url)
# 				except:
# 					pass
# 		except:
# 			print("failed")
# 			pass
# 	return urls

# ## Given the URL of Cyberdrop post, returns downloadable urls of each items in the gallery.
# def downloadCD(url):
#     r = requests.get(url).text
#     urls = []
#     pics = r.split('downloadUrl: "')
#     for durl in pics[1:]:
#         urls.append(durl.split('",\n')[0])
#     vids = r.split('mp4" data-html')
#     for vurl in vids[1:]:
#         vvurl = vurl.split('href="')[1]
#         url = vvurl.split('" target=')[0]
#         urls.append(url)
#     print(len(urls))

#     return jsonify({'urls':urls})

# def is_18(sub):
# 	reddit = praw.Reddit(client_id=prawInfo['client_id'], \
#                      client_secret=prawInfo['client_secret'], \
#                      user_agent=prawInfo['user_agent'], \
#                      username=prawInfo['username'], \
#                      password=prawInfo['password'])
# 	subred = reddit.subreddit(sub)
# 	return subred.over18

# #Recently Added URLs
# def recents(nsfw):
# 	recents = []
# 	content = current_app.database.execute(text("""
# 		SELECT
# 			id,
# 			sub,
# 			urls,
# 			type,
# 			time
# 		FROM
# 			urls
# 		ORDER BY
# 			id DESC
# 		WHERE
# 			nsfw = :pnsfw
# 		LIMIT
# 			5
# 	"""),{'pnsfw':nsfw}).fetchall()
# 	for post in content:
# 		recents.append(post)
# 	return recents

# #Popular posts based on the popular subs. Grab 5 subs with most hits -> Grab the url with most hits of each.
# def populars(nsfw):
# 	populars = []

# 	pnsubs = current_app.database.execute(text("""
#         SELECT
# 			sub
# 		FROM
# 			subs
# 		WHERE
# 			nsfw = :pnsfw
# 		ORDER BY
# 			hits DESC
# 		LIMIT
# 			5
#     	"""),{'pnsfw':nsfw}).fetchall()
# 	for pnsub in pnsubs:
# 		content = current_app.database.execute(text("""
# 		SELECT
# 			id,
# 			sub,
# 			urls,
# 			type,
# 			time
# 		FROM
# 			urls
# 		WHERE
# 			sub = :subn
# 		ORDER BY
# 			hits DESC
# 		"""),{'subn':pnsub['sub']}).fetchone()
# 		populars.append(content)
# 	return populars

# def dailyPopRS():
# 	# Find Popular Posts on Reddit's all.
# 	dayPos = []
# 	dayNPos = []
# 	reddit = praw.Reddit(client_id=prawInfo['client_id'], \
#         client_secret=prawInfo['client_secret'], \
#         user_agent=prawInfo['user_agent'], \
#         username=prawInfo['username'], \
#         password=prawInfo['password'])
# 	all = reddit.subreddit('all').hot(limit=100)
# 	subs = set()
# 	nsfwSubs = set()
# 	for post in all:
# 		sub = post.subreddit
# 		if sub.over18:
# 			if len(nsfwSubs)<5:
# 				nsfwSubs.add(str(sub))
# 		elif len(subs)<5:
# 			subs.add(str(sub))

# 	for sub in subs:
# 		urls = search_sub(sub,'all','top')
# 		if get_sub(sub) == None:
# 			insert_sub({'sub':sub,'nsfw':int(is_18(sub))})
# 		id = insert_url({'urls':str(urls),'type':'top','time':'all','sub':sub,'nsfw':int(is_18(sub))})
# 		content = get_url_id(id)
# 		dayPos.append(content)
	
# 	for sub in nsfwSubs:
# 		urls = search_sub(sub,'all','top')
# 		if get_sub(sub) == None:
# 			insert_sub({'sub':sub,'nsfw':int(is_18(sub))})
# 		id = insert_url({'urls':str(urls),'type':'top','time':'all','sub':sub,'nsfw':int(is_18(sub))})
# 		content = get_url_id(id)
# 		dayNPos.append(content)

# 	return {"dayPos":dayPos,"dayNPos":dayNPos}



###############################################################
#					   	  Decorators                          #
###############################################################
def login_required(f):  #name of the decorator
	@wraps(f)
	def decorated_function(*args, **kwargs):
		access_token = request.headers.get('Authroization')
		if access_token is not None:
			try:
				payload = jwt.decode(access_token, current_app.config['JWT_SECRET_KEY'], 'HS256')
			except jwt.InvalidTokenError:
				payload = None
			
			if  payload is None: return Response(status=401)

			user_id = payload['user_id']
			g.user_id = user_id
			g.user = get_user(user_id) if user_id else None
		else:
			return Response(status=401)

		return f(*args, **kwargs)
	return decorated_function


# using mysql with mysql connector now
def create_app(test_config = None):
	app = Flask(__name__)

	CORS(app)
	
	# today = str(date.today())
	# recent = recents(0)
	# recentN = recents(1)
	# pops = populars(0) 
	# popsN = populars(1)
	# dp = dailyPopRS()
	# todays = dp['dayPos']
	# todaysN = dp['dayNPos']

	# method_requests_mapping = {
	# 	'GET': requests.get,
	# 	'HEAD': requests.head,
	# 	'POST': requests.post,
	# 	'PUT': requests.put,
	# 	'DELETE': requests.delete,
	# 	'PATCH': requests.patch,
	# 	'OPTIONS': requests.options,
	# }

	if test_config is None:
		app.config.from_pyfile("config.py")
	else:
		app.config.update(test_config)

	database = create_engine(app.config['DB_URL'], encoding = 'utf-8', max_overflow = 0)
	app.database = database

	app.json_encoder = CustomJSONEncoder

	# @app.route("/api/ping", methods=['GET'])
	# def ping():
	# 	return "pong"
	
	# @app.route('/api/dcnt', methods=['GET'])
	# def dcnt():
	# 	if today != str(date.today()):
	# 		recent = recents(0)
	# 		recentN = recents(1)
	# 		pops = populars(0) 
	# 		popsN = populars(1)
	# 		dp = dailyPopRS()
	# 		todays = dp['dayPos']
	# 		todaysN = dp['dayNPos']

	# @app.route('/api/search', methods=['GET'])
	# def search():
	# 	if today != str(date.today()):
	# 		recent = recents(0)
	# 		recentN = recents(1)
	# 		pops = populars(0) 
	# 		popsN = populars(1)
	# 		dp = dailyPopRS()
	# 		todays = dp['dayPos']
	# 		todaysN = dp['dayNPos']
	# 	sub = request.args.get('sub')
	# 	num = int(request.args.get('num'))
	# 	tim = request.args.get('tim')
	# 	typ = request.args.get('typ')
	# 	dated = request.args.get('date')
	# 	rurl = {}
	# 	if tim == '':
	# 		url = get_url({'sub':sub,'stype':typ,'sdate':dated})
	# 	else:
	# 		url = getT_url({'sub':sub,'stype':typ,'sdate':dated,'stim':tim})
	# 	if url == None:
	# 		print("URL NOT FOUND")
	# 		if get_sub(sub) == None:
	# 			print("SUB NOT FOUND")
	# 			insert_sub(jsonify({'sub':sub,'nsfw':int(is_18(sub))}))
	# 		else:
	# 			print("SUB FOUND")
	# 			increment_hits_sub(sub)
	# 		rurl = search_sub(sub, tim, num, typ)
	# 		insert_url({'urls':rurl,'type':typ,'time':tim,'nump':num,'sub':sub,'nsfw':int(is_18(sub))})
	# 	else:
	# 		print("URL FOUND, sub and url hitcounts incremented")
	# 		rurl = url['urls']
	# 		increment_hits_sub(sub)
	# 		increment_hits_url(rurl['id'])

	# 	return jsonify({'url':rurl})

	# @app.route('/api/cors/<path:url>', methods=method_requests_mapping.keys())
	# def purl(url):
	# 	requests_function = method_requests_mapping[request.method]
	# 	req = requests_function(url, stream=True, params=request.args)
	# 	response = Response(stream_with_context(req.iter_content()),
	# 							content_type=req.headers['content-type'],
	# 							status=req.status_code)
	# 	response.headers['Access-Control-Allow-Origin'] = '*'
	# 	return response

	# @app.route('/api/url', methods=['GET'])
	# def url():
	# 	return jsonify({'url' : 'reddit.com', 'download' : 'downloadit'})

	# @app.route('/api/list', methods=['GET'])
	# def liste():
	# 	return jsonify({'sub': 'subname', 'urls':'["https://i.redd.it/xiwx5di1h6i71.jpg","https://i.redd.it/enjfvmtll4i71.png"]'})

	# @app.route('/api/down', methods=['GET'])
	# def down():
	# 	sub = request.args.get('sub')
	# 	num = int(request.args.get('num'))
	# 	tim = request.args.get('tim')
	# 	typ = request.args.get('typ')
	# 	urls = []

	# 	reddit = praw.Reddit(client_id=prawInfo['client_id'], \
	# 		client_secret=prawInfo['client_secret'], \
	# 		user_agent=prawInfo['user_agent'], \
	# 		username=prawInfo['username'], \
	# 		password=prawInfo['password'])
	# 	subred = reddit.subreddit(sub)
	# 	print(sub,num,typ,tim)

	# 	if typ == 'top':
	# 		Posts = subred.top(time_filter=tim, limit=num)
	# 	elif typ == 'new':
	# 		Posts = subred.new()

	# 	for post in Posts:
	# 		try:
	# 			url = post.url
	# 			extens = url.split(".")[-1]
	# 			if extens == 'jpg' or extens == 'png':
	# 				urls.append(url)
	# 			elif extens == 'gifv':
	# 				urls.append(url)
	# 			elif url.split('/')[2] == 'redgifs.com':
	# 				try:
	# 					r = requests.get(url)
	# 					spl = r.text.split('/')
	# 					num = 88
	# 					for i in range(5):
	# 						if spl[num+i].rfind('.mp4') != -1:
	# 							mark = spl[num+i].split('"')[0]
	# 					url = 'https://thumbs2.redgifs.com/'+mark
	# 					urls.append(url)
	# 				except:
	# 					pass
	# 		except:
	# 			pass
	# 	print(len(urls))
	# 	return jsonify(urls)

	return app


