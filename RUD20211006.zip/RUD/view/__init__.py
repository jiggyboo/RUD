from flask import request, jsonify, current_app, Response, g
from flask.json import JSONEncoder
from functools import wraps

def create_endpoints(app, services):
    db_work = services.db_work
    dc_cache = services.dc_cache


    @app.route("/sign-up", moethods=['POST'])
    def sign_up():
        new_user = request.json
        new_user_id = user_service.create_new_user(new_user)
        new_user = user_service.get_user(new_user_id)

        return jsonify(new_user)

    @app.route("/api/ping", methods=['GET'])
    def ping():
        return "pong"

    @app.route("/api/dcnt", methods=['GET'])
    def dcnt():
        return dc_cache.dcnt()

    @app.route("/api/search", methods=['GET'])
    def search():
        sub = request.args.get('sub')
    	num = int(request.args.get('num'))
        tim = request.args.get('tim')
        typ = request.args.get('typ')
        dated = request.args.get('date')

        return db_work.search(sub, num, tim, typ, dated)
