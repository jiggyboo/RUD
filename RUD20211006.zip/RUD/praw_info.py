prawInfo = {
    'client_id' : 'z1eHTSoHlmqgkw',
    'client_secret' : 'Y3g69V7w6_drdPkfiFenPWb6azh2tQ',
    'user_agent' : 'stkRadar',
    'username' : 'Great-Practice3637',
    'password' : 'satrhdqn19'
}